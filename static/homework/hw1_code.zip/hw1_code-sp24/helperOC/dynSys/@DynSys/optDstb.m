function dOpt = optDstb(obj, ~, ~, ~, ~, ~)
% dOpt = optDstb(obj, ~, ~, ~, ~, ~)
%     Default optimal disturbance function for systems with no disturbance

dOpt = [];

end