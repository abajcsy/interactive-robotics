function uOpt = optCtrl(obj, ~, ~, ~, ~, ~)
% uOpt = optCtrl(obj, ~, ~, ~, ~, ~)
%     Default optimal control function for systems with no control

uOpt = [];

end