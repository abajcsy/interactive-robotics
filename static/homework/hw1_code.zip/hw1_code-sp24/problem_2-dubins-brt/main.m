%% YOUR CODE HERE. Hint: look for createGrid() function
% Define the grid for the computation: g
% g = ...


%% YOUR CODE HERE. Hint: look into shapeSphere() function 
% Define the failure set as encoded by the signed distance function. 
% We use data0 to denote this initial signed distance function from 
% which the value function is computed. 
% data0 = ....


%% time vector
t0 = 0;
tMax = 2;
dt = 0.05;
tau = t0:dt:tMax;

%% problem parameters

% input bounds
speed = 1.5;
wMax = 0.5;

% is the agent control trying to min or max value function?
uMode = 'max';

%% Pack problem parameters

% Define dynamic system
dCar = DubinsCar([0, 0, 0], wMax, speed); %do dStep3 here

% Put grid and dynamic systems into schemeData
schemeData.grid = g;
schemeData.dynSys = dCar;
schemeData.accuracy = 'high'; %set accuracy
schemeData.uMode = uMode;

%% Compute value function
% HJIextraArgs.visualize = true; %show plot
HJIextraArgs.visualize.valueSet = 1;
HJIextraArgs.visualize.initialValueSet = 1;
HJIextraArgs.visualize.figNum = 1; %set figure number
HJIextraArgs.visualize.deleteLastPlot = false; %delete previous plot as you update

% uncomment if you want to see a 2D slice
% HJIextraArgs.visualize.plotData.plotDims = [1 1]; % plot x, y
HJIextraArgs.visualize.viewAngle = [0,90]; % view 2D

% The format of this function looks like: 
%   [data, tau, extraOuts] = ...
%           HJIPDE_solve(data0, tau, schemeData, minWith, extraArgs)
[data, tau2, ~] = ...
  HJIPDE_solve(data0, tau, schemeData, 'zero', HJIextraArgs);