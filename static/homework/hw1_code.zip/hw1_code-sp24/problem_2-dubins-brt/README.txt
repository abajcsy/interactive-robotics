Interactive Robotics - Spring 2024 - Instructor: Prof. Andrea Bajcsy
Student Code Template - HW 1 - Problem 2

Written by: 
Andrea Bajcsy (abajcsy@cmu.edu) 
*******************************************************************************************

TASK: You need to compute the BRT and the optimal controller for a human model.
Specifically, you are required to fill in the files:
    1. main.m
    You need to define the grid and the target function for the computation.

    2. @DubinsCar/optCtrl.m
    You need to compute the optimal controller depending on whether it is 
    trying to minimize or maximize the value function.

