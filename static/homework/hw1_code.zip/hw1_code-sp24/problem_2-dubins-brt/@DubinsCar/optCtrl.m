function uOpt = optCtrl(obj, ~, ~, deriv, uMode)
% uOpt = optCtrl(obj, t, y, deriv, uMode)

%% Input processing
if nargin < 5
  uMode = 'min';
end

if ~iscell(deriv)
  deriv = num2cell(deriv);
end

%% YOUR CODE HERE.
%% Optimal control
if strcmp(uMode, 'max')
  uOpt = ...; % fill this out
elseif strcmp(uMode, 'min')
  uOpt = ...; % fill this out
else
  error('Unknown uMode!')
end

end