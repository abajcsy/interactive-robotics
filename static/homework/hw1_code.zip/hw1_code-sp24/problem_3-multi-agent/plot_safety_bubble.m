function [h] = plot_safety_bubble(params, trajA, trajB)
% % Plot safety bubble in the relative coordinate system.
figure(4)
hold on 
valfunc = params.data(:,:,:,end);
xrel_curr = global_to_rel_state(trajA(:,end), trajB(:,end));
plt_val = eval_u(params.g, valfunc, xrel_curr)

[gPlot, dataPlot] = proj(params.g, valfunc, [0,0,1], xrel_curr(3));

twodplt_val = eval_u(gPlot, dataPlot, xrel_curr(1:2))
[~, h] = contourf(gPlot.xs{1}, ...
                gPlot.xs{2}, ...
                dataPlot); %[0,0], 'color', acolor);
[~, h] = contour(gPlot.xs{1}, ...
                gPlot.xs{2}, ...
                dataPlot, [0,0], 'color', 'w', 'linewidth', 2);
xlabel("x-rel")
ylabel("y-rel")
title("Safety Value: V(x-rel,y-rel)")
scatter(xrel_curr(1), xrel_curr(2), ...
    'MarkerFaceColor', 'k', 'MarkerEdgeColor', 'w', 'linewidth', 2)
hold off
colorbar;
colormap('rdylbu')
end

